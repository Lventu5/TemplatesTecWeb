package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Data implements Serializable {
	private List<User> users;
	private List<Monument> tourMap;

	private static final long serialVersionUID = 1L;
	
	public Data() {
		super();
		users = new ArrayList<>();
		tourMap = new ArrayList<>();
		
		users.add(new User("peppe","brescia"));
		users.add(new User("pippo","nana"));
		users.add(new User("abcd","1234"));
		users.add(new User("io","2345"));
		users.add(new User("aaa","aaa"));
		users.add(new User("bbb","bbb"));
		users.add(new User("ccc","ccc"));
		users.add(new User("ddd","ddd"));
		
		tourMap.add(new Monument("Municipio",new Pos(5,5)));
		tourMap.add(new Monument("Castello",new Pos(0,1)));
		tourMap.add(new Monument("Cattdrale",new Pos(1,2)));
		tourMap.add(new Monument("Mura",new Pos(2,2)));
		tourMap.add(new Monument("Bastione",new Pos(1,3)));
		tourMap.add(new Monument("Belvedere",new Pos(4,5)));
	}
	
	public List<User> getMap(){
		return users;
	}
	
	public List<Monument> getMonuments(){
		return tourMap;
	}
	
	public boolean isReg(String uName, String pwd) {
		for(User u : users) {
			if(u.getUname().equals(uName) && u.getPwd().equals(pwd)) return true;
		}
		return false;
	}
	
	public List<Monument> getVisibleMonuments(Pos pos) {
		return this.tourMap.stream().filter(m -> m.getPos().getDistance(pos)==0).toList();
	}
	
	public User getUser(String uName, String pwd) {
		for(User u : users) {
			if(u.getUname().equals(uName) && u.getPwd().equals(pwd)) return u;
		}
		return null;
	}
	
}
