package it.unibo.tw.web.beans;

import java.io.Serializable;

public class Monument implements Serializable {
	private String name;
	private Pos pos;

	private static final long serialVersionUID = 1L;
	
	public Monument(String name, Pos pos) {
		super();
		this.name=name;
		this.pos=pos;
	}
	
	public String getName() {
		return this.name;
	}
	
	public Pos getPos() {
		return pos;
	}

}