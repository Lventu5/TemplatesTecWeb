package it.unibo.tw.web.beans;

import java.io.Serializable;

public class User implements Serializable {
	private String uName, pwd;
	private Pos pos;

	private static final long serialVersionUID = 1L;
	
	public User(String name, String pwd) {
		super();
		this.uName=name;
		this.pwd=pwd;
		this.pos=new Pos(0,0);
	}
	
	public String getUname() {
		return this.uName;
	}
	
	public String getPwd() {
		return this.pwd;
	}
	
	public Pos getPos() {
		return pos;
	}
	
	public void setPos(int x, int y) {
		pos.setPos(x, y);
	}

}