package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Data implements Serializable {
	private List<Player> players;

	private static final long serialVersionUID = 1L;
	
	public Data() {
		super();
		players = new ArrayList<>();
		
		players.add(new Player("Boh",16,0,9,5,1));
		players.add(new Player("Musetti",15,0,10,5,1));
		players.add(new Player("Rune",14,0,12,4,1));
		players.add(new Player("Sonego",13,0,13,4,1));
		players.add(new Player("Ciao",12,0,14,4,2));
		players.add(new Player("Black",11,0,15,4,2));
		players.add(new Player("Taba",10,1,16,3,2));
		players.add(new Player("Prova",9,2,17,3,2));
	}
	
	public List<Player> getPlayers(){
		return players;
	}
	
	public List<Player> getPlayersTab(int side) {
		return this.players.stream().filter(p -> p.getTab()==side).toList();
	}
	
	public Player getPlayer(String name) {
		for(Player p : players) {
			if(p.getName().equals(name)) return p;
		}
		return null;
	}
	
}
