package it.unibo.tw.web.beans;

import java.io.Serializable;

public class Player implements Serializable {
	private String name;
	private int rank, champ, wins, loss, tab;

	private static final long serialVersionUID = 1L;
	
	public Player(String name, int rank, int champ, int wins, int loss, int tab) {
		super();
		this.name = name;
		this.rank = rank;
		this.champ = champ;
		this.wins = wins;
		this.loss = loss;
		this.tab = tab;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getChamp() {
		return champ;
	}

	public void setChamp(int champ) {
		this.champ = champ;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}

	public int getLoss() {
		return loss;
	}

	public void setLoss(int loss) {
		this.loss = loss;
	}

	public int getTab() {
		return tab;
	}

	public void setTab(int tab) {
		this.tab = tab;
	}
	
}