package it.unibo.tw.web.beans;

import java.io.Serializable;

import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class Pos implements Serializable {
	private int x, y;

	private static final long serialVersionUID = 1L;
	
	public Pos(int x, int y) {
		super();
		this.x=x;
		this.y=y;
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	public int[] getPos() {
		int[] res = {this.x, this.y};
		return res;
	}
	
	public void setPos(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
	public double getDistance(Pos p) {
		return Math.sqrt((p.getX()-this.x)*(p.getX()-this.x)+(p.getY()-this.y)*(p.getY()-this.y));
	}
	
	public String toString() {
		return "("+this.x+","+this.y+")";
	}

}