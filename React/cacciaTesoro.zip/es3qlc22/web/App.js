class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        treasure: [],
        newGame: true,
        end: false,
        dimx: 0, 
        dimy: 0,
        taken: 0,
        points: 0
       };
       
       this.setConfigs = this.setConfigs.bind(this);
       this.gameOn = this.gameOn.bind(this);
  }

  /*resetGrid(){
    for(var i=0;i<this.state.dimx;i++){
      for(var j=0;j<this.state.dimy;j++){
        var x = "r_"+i+"_td_"+j;
        document.getElementById(x).style.backgroundColor = "gray";
      }
    }
  }*/

  gameOn(event) {
    var posx = parseInt(event.target.id.split("_")[1]), posy = parseInt(event.target.id.split("_")[3]);

    if(this.state.treasure[0]===posx && this.state.treasure[1] === posy){
        event.target.style.backgroundColor = "blue";
        event.target.style.color = "white";
        alert("Partita terminata: tesoro trovato!");
        //this.resetGrid();

        /*var temp = [];
	    var x = Math.floor(Math.random() * (document.getElementById("dimx").value));
		temp.push(x);
		var y = Math.floor(Math.random() * (document.getElementById("dimy").value));
		temp.push(y);*/
		
		var pts;
		if(this.state.taken<=10) pts=5;
		else pts=2;

        this.setState({
          //taken: 0,
          //treasure: temp,
          end: true,
          points: pts
        });
    }
    else{
        event.target.style.backgroundColor = "yellow";
        this.setState({
            taken: this.state.taken+1
       	});
    }
  };

  setConfigs(){    
    this.setState({ 
        dimx: document.getElementById("dimx").value,
        dimy: document.getElementById("dimy").value,
        newGame: false
    }); 
    
    var temp = [];
    var x = Math.floor(Math.random() * (document.getElementById("dimx").value));
	temp.push(x);
	var y = Math.floor(Math.random() * (document.getElementById("dimy").value));
	temp.push(y);

	this.setState({treasure: temp});
  };


  render() {
    if(this.state.newGame){
        return(
			  <div style={{display: 'flex', justifyContent: 'center'}}>
            <Config setConfigs={this.setConfigs}/>
            </div>
        );
    }
    else{
        return (
			<div style={{display: 'flex', justifyContent: 'center'}}>
            <Mappa dimx={this.state.dimx} dimy={this.state.dimy} pos={this.state.treasure} onClick={this.gameOn}/>
            <Stats end={this.state.end} taken={this.state.taken} points={this.state.points}/>
            </div>
        );
    }
  }
}