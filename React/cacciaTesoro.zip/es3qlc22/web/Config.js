class Config extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div className="config">
            	<h1>Caccia al tesoro</h1>
                <h2>Configurations</h2>
                <table>
                    <tr>
                        <th>Number of rows</th>
                        <th>Number of columns</th>
                    </tr>
                    <tr>
                        <td><input type="number" id="dimx" min="5" max="30" /></td>
                        <td><input type="number" id="dimy" min="5" max="30" /></td>
                    </tr>
                </table>
                <input type="button" value="Start" onClick={this.props.setConfigs} />
            </div>
        );
    }
}