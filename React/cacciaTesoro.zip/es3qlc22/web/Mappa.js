class Mappa extends React.Component {

    render() {
        var rows = [];
        var head = [];

        for(var i = 0; i<this.props.dimx; i++){
            var r = <Row dim={this.props.dimy} rowNumber={i} pos={this.props.pos} onClick={this.props.onClick}/>;
            rows.push(r);
        }
        

        return(
			<div>
			<h1>Trova il tesoro!</h1>
            <table style={{borderCollapse: 'collapse', width: '100%'}}>
                <tr>
                    {head}
                </tr>
                {rows}
            </table>
            </div>
        );
    }

}