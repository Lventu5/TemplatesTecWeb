class Row extends React.Component {
  constructor(props) {
      super(props);
  }
  render() {
    var y = this.props.dim;
    var cells = [];
    for(var i = 0; i<y; i++){
        var x = "r_"+ this.props.rowNumber +"_td_" + i;
        var td;
        if(this.props.pos[0]===this.props.rowNumber && this.props.pos[1]===i){
			td = <td id={x} style={{border: '1px solid black', width: '45px', height: '45px', backgroundColor: 'gray', color: 'gray', textAlign: 'center', fontSize: '1.5em'}} onClick={this.props.onClick}>T</td>
		}
        else td = <td id={x} style={{border: '1px solid black', width: '45px', height: '45px', backgroundColor: 'gray'}} onClick={this.props.onClick}></td>
        cells.push(td);
    }
    return (
      <tr>
        {cells}
      </tr>
    );
  }
}