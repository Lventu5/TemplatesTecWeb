class Stats extends React.Component {
	
	render(){ 
		var pts = ""; 
		if(this.props.end) pts=<li>Punti ottenuti: {this.props.points}</li>
        return(
			<div>
			<ul>
				<li>Tentativi falliti: {this.props.taken}</li>
				{pts}
			</ul>
			</div>
		)
	}
}