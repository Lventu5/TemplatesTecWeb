class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        end: false,
        winners: [],
        positions: [],
        newGame: true,
        numCars: 0,
        colors: ["Red", "Blue", "Green", "Yellow", "Purple", "Orange"],
        interval: null, 
        time: 0,
        pace: [],
        leader: -1
       };
       
       this.setConfigs = this.setConfigs.bind(this);
       this.updatePos = this.updatePos.bind(this);
       this.gameOn = this.gameOn.bind(this);
       this.updateStats = this.updateStats.bind(this);
  }

  updatePos(x, num){
    var oldPos = this.state.positions[x];
    var y = oldPos + num;
    if(y>=10){
        y = 10;
        this.setState({winners: [ ...this.state.winners, x]});
    }
    var idNew = "r_"+ x +"_td_" + y;
    var idOld = "r_"+ x +"_td_" + oldPos;
    document.getElementById(idOld).style.border = "1px solid black";
    document.getElementById(idNew).style.border = "3px solid " + this.state.colors[x];
    var temp = this.state.positions.map((el, index) => {
		if(index === x) return el+num;
		else return el;
	});
	this.setState({ positions: temp});
  }
  
  updateStats(){
	  var temp=[];
	  var max=-1, index=-1;
	  for(var i=0;i<this.state.numCars;i++){
		  temp.push(this.state.positions[i]/this.state.time);
		  if(this.state.positions[i]>max) {
			  max = this.state.positions[i];
			  index = i;
		  }
	  }
	  this.setState({
		  pace: temp,
		  leader: index
	  });
  }

  gameOn() {
    for(var i = 0; i<this.state.numCars; i++){
        var n = Math.floor(Math.random() * (4));
        this.updatePos(i, n);
    }
    this.updateStats();
    if(this.state.winners.length != 0){
        this.setState({end: true});
        alert("The winners are cars number: " + this.state.winners);
        clearInterval(this.state.interval);
        this.setState({ end: true});
        setTimeout(() => {
			var temp = [];
		    for(var i = 0; i<this.state.numCars; i++){
				temp.push(0);
			}
			
			this.setState({
				newGame: true,
				leader: -1,
				positions: temp,
				pace: temp,
				winners: [],
				end: false,
				time: 0
        	})}, 5000);
    }
  };

  setConfigs(){    
    this.setState({ 
        numCars: document.getElementById("numCars").value,
        newGame: false
    }); 
    
    var temp = [];
    for(var i = 0; i<document.getElementById("numCars").value; i++){
		temp.push(0);
	}
	this.setState({positions: temp, pace: temp});
	
	this.setState({interval: setInterval(() => {
		this.setState({time : this.state.time+4});
		this.gameOn();
		}, 4000)});
  };


  render() {
    if(this.state.newGame){
        return(
			<div style={{display: 'flex', justifyContent: 'center'}}>
            <Config setConfigs={this.setConfigs}/>
            </div>
        );
    }
    else{
        return (
			<div style={{display: 'flex', justifyContent: 'center'}}>
            <Pista numCars={this.state.numCars} colors={this.state.colors} />
            <Stats numCars={this.state.numCars} leader={this.state.leader} pace={this.state.pace} time={this.state.time} end={this.state.end}/>
            </div>
        );
    }
  }
}