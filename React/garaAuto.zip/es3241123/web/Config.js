class Config extends React.Component {

    render(){
		console.log(this.props.setConfigs);
        return(
            <div className="config" style={{textAlign: 'center'}}>
                <h2>Configurations</h2>
                <p>Number of cars (between 2 and 4)</p><br/>
                <input type="number" id="numCars" min="2" max="4" /><br/>
                <button name="Start" onClick={this.props.setConfigs}>Start</button>
                
            </div>
        );
    }
}