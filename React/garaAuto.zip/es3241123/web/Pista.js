class Pista extends React.Component {
	
	componentDidMount(){
		for(var i = 0; i<this.props.numCars; i++){
			var id = "r_"+ i +"_td_0";
			document.getElementById(id).style.border = "3px solid " + this.props.colors[i];
		}
	}

    render() {
        var cars = [];
        var head = [];

        for(var i = 0; i<11; i++){
            head[i] = (i==0) ? <th style={{width: '9%'}}>Start</th> : (i==10) ? <th style={{width: '9%'}}>Finish</th> : <th style={{width: '9%'}}>{i}</th>;
        }
        for(var i = 0; i<this.props.numCars; i++){
			console.log(this.props.colors[i]);
            var car = <Row color={this.props.colors[i]} rowNumber={i} />;
            cars.push(car);
        }
        

        return(
			<div>
            <table style={{borderCollapse: 'collapse', width: '80%'}}>
                <tr>
                    {head}
                </tr>
                {cars}
            </table>
            </div>
        );
    }

}