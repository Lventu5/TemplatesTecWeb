class Row extends React.Component {
  constructor(props) {
      super(props);
  }
  render() {
    var y = 11;
    var cells = [];
    for(var i = 0; i<y; i++){
        var x = "r_"+ this.props.rowNumber +"_td_" + i;
        var td = <td id={x} style={{border: '1px solid black', width: '35px', height: '15px'}}></td>
        cells.push(td);
    }
    return (
      <tr>
        {cells}
      </tr>
    );
  }
}