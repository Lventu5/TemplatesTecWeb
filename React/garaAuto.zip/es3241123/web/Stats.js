class Stats extends React.Component {
	
	render(){
		var vels = [];
		for(var i = 0; i<this.props.numCars; i++){
			var vel = <li>Car {i}: {this.props.pace[i]} blocks/second</li>
			vels.push(vel); 
        }
        var duration = "";
        if(this.props.end){
			duration="Durata della gara: "+this.props.time+" secondi";
		}
        
        return(
			<div>
			<ul>
			{vels}
			</ul>
			<br/>
			Current leader: {this.props.leader}
			<br/>
			{duration}
			</div>
		)
	}
}