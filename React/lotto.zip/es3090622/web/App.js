class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        vals: [],
        inputs: [],
        newGame: true
       };
       
       this.setConfigs = this.setConfigs.bind(this);
       this.gameOn = this.gameOn.bind(this);
  }

  gameOn() {
	  var temp=[], winners1=[], winners2=[];
	  for(var i=0;i<5;i++){
		  var num = Math.floor((Math.random()*9)+1);
		  while(temp.length!=0 && temp.includes(num)){
			  num = Math.floor((Math.random()*9)+1);
		  }
		  temp.push(num);
		  document.getElementById('r_1_'+i).value=num;
		  var ind = this.state.inputs.indexOf(num);
		  if(ind != -1){
			  winners1.push(ind);
			  winners2.push(i);
		  }
	  }
	  
	  var res=['Non vincente','Non vincente','Ambo','Terno','Quaterna','Cinquina'];
	  if(winners1.length>=2){
		  var colors=['yellow','green','blue','red']
		  for(var i=0;i<winners1.length;i++){
			  var x="r_0_"+winners1[i], y="r_1_"+winners2[i];
			  document.getElementById(x).style.backgroundColor=colors[winners1.length-2];
			  document.getElementById(y).style.backgroundColor=colors[winners1.length-2];
		  }
	  }
	  document.getElementById("result").innerHTML = res[winners1.length]
  };

  setConfigs(){   
	  var temp=[], empty=[]; 
	  for(var i=0;i<5;i++){
		  var id="inp"+i;
		  temp.push(parseInt(document.getElementById(id).value));
		  empty.push("");
	  }
	  
	  this.setState({ 
	      inputs: temp,
	      vals: empty,
	      newGame: false
	  }); 
    
	  
  };


  render() {
    if(this.state.newGame){
        return(
			<div style={{margin: 'auto'}}>
            <Config setConfigs={this.setConfigs}/>
            </div>
        );
    }
    else{
        return (
			<div style={{margin: 'auto'}}>
            <Row rowNumber="0" nums={this.state.inputs}/>
            <Row rowNumber="1" nums={this.state.vals}/>
            <button id="start" onClick={this.gameOn}>Estrazione</button>
            <p id="result" style={{fontSize: '3em'}}></p>
            </div>
        );
    }
  }
}