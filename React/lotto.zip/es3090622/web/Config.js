class Config extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
		var heads = [], inputs=[];
		for(var i=0;i<5;i++){
			var x="inp"+i;
			heads.push(<th>{i}</th>);
			inputs.push(<td><input type="number" id={x} style={{border: '1px solid black', width: '90px', height: '45px', textAlign: 'center'}} min="1" max="10" /></td>)
		}
        return(
            <div className="config" style={{margin:'auto'}}>
            	<h1>Lotto virtuale</h1>
                <h2>Compila la schedina</h2>
                <table>
                    <tr>
                        {heads}
                    </tr>
                    <tr>
                        {inputs}
                    </tr>
                </table>
                <input type="button" value="Start" onClick={this.props.setConfigs} />
            </div>
        );
    }
}