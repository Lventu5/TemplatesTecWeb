class Row extends React.Component {
  constructor(props) {
      super(props);
  }
  render() {
    var cells = [];
    for(var i = 0; i<5; i++){
        var x = "r_"+ this.props.rowNumber +"_" + i;
        var inp;
		inp = <input type="text" id={x} style={{border: '1px solid black', width: '90px', height: '45px', textAlign: 'center', fontSize: '1.5em'}} readOnly value={this.props.nums[i]} />
		
        cells.push(inp);
    }
    return (
		<div style={{margin: 'auto'}}>
        	{cells[0]}{cells[1]}{cells[2]}{cells[3]}{cells[4]}
        	<br />
        	<br />
        </div>
    );
  }
}