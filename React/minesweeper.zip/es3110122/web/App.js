class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        bombs: [],
        newGame: true,
        dim: 0, 
        steps: 0,
        taken: 0,
        comp: 0,
        nonComp: 0,
        points: 0,
        totPoints: 0
       };
       
       this.setConfigs = this.setConfigs.bind(this);
       this.gameOn = this.gameOn.bind(this);
  }

  resetGrid(){
    for(var i=0;i<this.state.dim;i++){
      for(var j=0;j<this.state.dim;j++){
        var x = "r_"+i+"_td_"+j;
        document.getElementById(x).style.backgroundColor = "yellow";
      }
    }
  }

  gameOn(event) {
    var row = parseInt(event.target.id.split("_")[1]), pos = parseInt(event.target.id.split("_")[3]);

    if(this.state.bombs[row]*2===pos || this.state.bombs[row]*2+1 === pos){
        event.target.style.backgroundColor = "red";
        alert("Partita terminata: percorso non completato!");
        this.resetGrid();

        var temp = [];
        for(var i = 0; i<2*this.state.dim; i++){
          var n = Math.floor(Math.random() * (this.state.dim));
          temp.push(n);
        }
        this.setState({
          taken: 0,
          bombs: temp,
          nonComp: this.state.nonComp+1,
          points: 0
        });
    }
    else{
        event.target.style.backgroundColor = "blue";
        if(parseInt(this.state.steps)===(this.state.taken+1)){
          alert("Partita terminata: percorso completato!");
		  this.resetGrid();
          var temp = [];
          for(var i = 0; i<2*this.state.dim; i++){
            var n = Math.floor(Math.random() * (this.state.dim));
            temp.push(n);
          }
          this.setState({
            taken: 0,
            bombs: temp,
            comp: this.state.comp+1,
            points: 0
          });
          
        }
        else {
          this.setState({
            taken: this.state.taken+1,
            points: this.state.points+5,
            totPoints: this.state.totPoints+5
          });
        }
    }
  };

  setConfigs(){    
    this.setState({ 
        dim: document.getElementById("dim").value,
        steps: document.getElementById("steps").value,
        newGame: false
    }); 
    
    var temp = [];
    for(var i = 0; i<2*document.getElementById("dim").value; i++){
      var n = Math.floor(Math.random() * (document.getElementById("dim").value));
		  temp.push(n);
	  }
	  this.setState({bombs: temp});
  };


  render() {
    if(this.state.newGame){
        return(
			  <div style={{display: 'flex', justifyContent: 'center'}}>
            <Config setConfigs={this.setConfigs}/>
            </div>
        );
    }
    else{
        return (
			<div style={{display: 'flex', justifyContent: 'center'}}>
            <Griglia dim={this.state.dim} onClick={this.gameOn}/>
            <Stats comp={this.state.comp} nonComp={this.state.nonComp} points={this.state.points} totPoints={this.state.totPoints}/>
            </div>
        );
    }
  }
}