class Config extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div className="config">
                <h2>Configurations</h2>
                <table>
                    <tr>
                        <th>Grid Size</th>
                        <th>Number of steps</th>
                    </tr>
                    <tr>
                        <td><input type="number" id="dim" min="5" max="20" /></td>
                        <td><input type="number" id="steps" min="3" /></td>
                    </tr>
                </table>
                <input type="button" value="Start" onClick={this.props.setConfigs} />
            </div>
        );
    }
}