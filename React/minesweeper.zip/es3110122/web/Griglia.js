class Griglia extends React.Component {

    render() {
        var rows = [];
        var head = [];

        for(var i = 0; i<this.props.dim; i++){
            var r = <Row dim={this.props.dim} rowNumber={i} onClick={this.props.onClick}/>;
            rows.push(r);
        }
        

        return(
			<div>
            <table style={{borderCollapse: 'collapse', width: '100%'}}>
                <tr>
                    {head}
                </tr>
                {rows}
            </table>
            </div>
        );
    }

}