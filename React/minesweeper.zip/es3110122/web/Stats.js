class Stats extends React.Component {
	
	render(){        
        return(
			<div>
			<ul>
				<li>Percorsi competati: {this.props.comp}</li>
				<li>Percorsi non completati: {this.props.nonComp}</li>
				<li>Punti questa partita: {this.props.points}</li>
				<li>Punti totali: {this.props.totPoints}</li>
			</ul>
			</div>
		)
	}
}