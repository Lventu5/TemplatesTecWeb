class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        fish: [],
        fishPr: [],
        newGame: true,
        end: false,
        dimx: 0,
        dimy: 0, 
        throws: 0,
        taken: 0,
        points: [],
        totPoints: 0
       };
       
       this.setConfigs = this.setConfigs.bind(this);
       this.gameOn = this.gameOn.bind(this);
       this.calcPoints = this.calcPoints.bind(this);
  }

  calcPoints(el){
	  var res = 0;
	  var x = parseInt(el.id.split("_")[1]), y = parseInt(el.id.split("_")[3]);
	  
	  var xin = Math.max(x-1,0), xf = Math.min(x+1,this.state.dimx-1);
	  var yin = Math.max(y-1,0), yf = Math.min(y+1,this.state.dimy-1);
	  var temp = this.state.fishPr;
	  for(var i = xin; i<=xf; i++){
		  for(var j = yin; j<=yf; j++){
			  var pos = "r_"+ i +"_td_" + j;
			  document.getElementById(pos).style.color = "red";
			  if(!this.state.fishPr.includes(pos)){
				  res+=this.state.fish[i][j];
				  temp.push(pos);
				  this.setState({ fishPr: temp});	
				}
				  /*else {
					  this.setState({
					  	fishPr: [...fishPr, pos]
				  	  });
				  }*/
		  }
	  }
	  return res;
  }

  gameOn(event) { 
	if(!this.state.end){ 
	    event.target.style.color = "red";
	    var pts = this.calcPoints(event.target);
	
	    if(parseInt(this.state.throws)===(this.state.taken+1)){
	      alert("Partita terminata: lanci terminati!");
	      this.setState({
	        points: [...this.state.points, pts],
	        totPoints: this.state.totPoints+pts,
	        end: true
	      }); 
	    }
	    else {
	      this.setState({
	        taken: this.state.taken+1,
	        points: [...this.state.points, pts],
	        totPoints: this.state.totPoints+pts
	      });
	    }
    }
  };

  setConfigs(){    
    this.setState({ 
        dimx: document.getElementById("dimx").value,
        dimy: document.getElementById("dimy").value,
        throws: document.getElementById("throws").value,
        newGame: false
    }); 
    
    var temp = [];
    for(var i = 0; i<document.getElementById("dimx").value; i++){
		var inner = [];
		for(var j = 0; j<document.getElementById("dimy").value; j++){
	      	var n = Math.floor(Math.random() * 5);
		  	inner.push(n);
	  	}
	  	temp.push(inner);
	}	
	this.setState({fish: temp});
  };


  render() {
    if(this.state.newGame){
        return(
			  <div style={{display: 'flex', justifyContent: 'center'}}>
            <Config setConfigs={this.setConfigs}/>
            </div>
        );
    }
    else{
        return (
			<div style={{display: 'flex', justifyContent: 'center'}}>
			
            <Lago dimx={this.state.dimx} dimy={this.state.dimy} fish={this.state.fish} onClick={this.gameOn}/>
            <Stats end={this.state.end} points={this.state.points} totPoints={this.state.totPoints}/>
            </div>
        );
    }
  }
}