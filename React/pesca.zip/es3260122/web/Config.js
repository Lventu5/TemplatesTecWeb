class Config extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div className="config">
                <h2>Configurations</h2>
                <table>
                    <tr>
                        <th>Lake Rows</th>
                        <th>Lake Columns</th>
                        <th>Number of throws</th>
                    </tr>
                    <tr>
                        <td><input type="number" id="dimx" min="8"/></td>
                        <td><input type="number" id="dimy" min="8" /></td>
                         <td><input type="number" id="throws" min="1" /></td>
                    </tr>
                </table>
                <input type="button" value="Start" onClick={this.props.setConfigs} />
            </div>
        );
    }
}