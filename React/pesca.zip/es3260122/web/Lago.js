class Lago extends React.Component {

    render() {
        var rows = [];
        var head = [];

        for(var i = 0; i<this.props.dimx; i++){
            var r = <Row dim={this.props.dimy} rowNumber={i} fish={this.props.fish[i]} onClick={this.props.onClick} />;
            rows.push(r);
        }
        

        return(
			<div>
			<h1>Gara di Pesca</h1><br/>
            <table style={{borderCollapse: 'collapse', width: '100%'}}>
                <tr>
                    {head}
                </tr>
                {rows}
            </table>
            </div>
        );
    }

}