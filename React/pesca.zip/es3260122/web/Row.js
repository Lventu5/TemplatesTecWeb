class Row extends React.Component {
  constructor(props) {
      super(props);
  }
  render() {
    var y = this.props.dim;
    var cells = [];
    for(var i = 0; i<y; i++){
        var x = "r_"+ this.props.rowNumber +"_td_" + i;
        var td = <td id={x} style={{border: '1px solid black', width: '45px', height: '45px', backgroundColor: 'gray', color:'gray', textAlign:'center', fontSize:'2em'}} onClick={this.props.onClick}>{this.props.fish[i]}</td>
        cells.push(td);
    }
    return (
      <tr>
        {cells}
      </tr>
    );
  }
}