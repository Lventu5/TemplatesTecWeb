class Stats extends React.Component {
	
	render(){  
		var vals = [], points = [];
		if(this.props.end){
			vals.push(<li>Punti totali: {this.props.totPoints}</li>)
			vals.push(<li>Punti medi per lancio: {this.props.totPoints/(this.props.points.length)}</li>)
		}
		for(var i=0;i<this.props.points.length;i++){
			points.push(<li>Punti nel lancio {i+1}: {this.props.points[i]}</li>)
		}     
        return(
			<div>
			<ul>
				{points}
				{vals}		
			</ul>
			</div>
		)
	}
}