class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = { 
        vals: ['','',''],
        credito: 0,
        points: [],
        plays: []
       };
       
       this.setCredito = this.setCredito.bind(this);
       this.gameOn = this.gameOn.bind(this);
  }

gameOn() {
	if(this.state.credito>=5){
		const vowels = ['a','e','i','o','u'];
		var temp=[];
		for(var i=0;i<3;i++){
			var ind = Math.floor((Math.random()*5));
			  
			temp.push(vowels[ind]);
			document.getElementById('r_0_'+i).value=vowels[ind];
			if(vowels[ind]==='a' || vowels[ind]==='e') document.getElementById('r_0_'+i).style.backgroundColor = 'green';
			else document.getElementById('r_0_'+i).style.backgroundColor = 'blue';
		}
		
		this.setState({
			plays: [...this.state.plays, temp[0]+','+temp[1]+','+temp[2]],
			credito: this.state.credito-5,
			vals: temp
		});
		
		if(temp[0]===temp[1] && temp[1]===temp[2]){
			this.setState({
				credito: this.state.credito+50,
				points: [...this.state.points, 50]
			});
		}
		else if((temp[0]===temp[1] && temp[0]!==temp[2]) || (temp[0]===temp[2] && temp[0]!==temp[1]) || (temp[1]===temp[2] && temp[0]!==temp[2])){
			this.setState({
				credito: this.state.credito+15,
				points: [...this.state.points, 15]
			});
		}
		else this.setState({ points: [...this.state.points, 0] });
	}
	  
};

  setCredito(){   	  
	  this.setState({ 
	      credito: this.state.credito+parseInt(document.getElementById("incremento").value)
	  }); 
  };


  render() {
        return(
			<div>
				<h1>Slot machine</h1>
				<hr/>
				<div id="container" style={{display: "flex", justifyContent: "space-around"}}>
				
		            <Credito setCredito={this.setCredito} credito={this.state.credito}/>
		            <div id="inner">
		            	<h3>Gioca</h3>
			            <Row rowNumber="0" vals={this.state.vals}/><br/>
			            <button id="start" onClick={this.gameOn}>Gioca</button>
			        </div>
		            <Stats plays={this.state.plays} points={this.state.points} />
	            </div>
            </div>
        );
  }
}
