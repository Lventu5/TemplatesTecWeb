class Credito extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div className="config">
                <h4>Inserisci credito nella slot</h4>
                <input type="number" id="incremento" style={{border: '1px solid black', width: '90px', height: '45px', textAlign: 'center'}} min="1" /><br/>
                <input type="number" id="credito" style={{border: '1px solid black', width: '90px', height: '45px', textAlign: 'center'}} readOnly value={this.props.credito}/><br/>
                <input type="button" value="Start" onClick={this.props.setCredito} />
            </div>
        );
    }
}