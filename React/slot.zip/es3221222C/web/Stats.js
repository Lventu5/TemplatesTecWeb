class Stats extends React.Component {
	
	render(){   
		var results = [];
		for(var i=0;i<this.props.points.length;i++){
			results.push(<li>Risultato della giocata {i+1}: {this.props.plays[i]}: {this.props.points[i]}</li>)
		}    
        return(
			<div>
			<ul>
				{results}
			</ul>
			</div>
		)
	}
}