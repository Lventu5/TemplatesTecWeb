package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {

	private static final long serialVersionUID = 1L;

	private Map<HttpSession, String> articoliAcceduti;
	private Map<String, HttpSession> articoliScrittura;
	private List<Articolo> articoli;
	
	public Data() {
		super();
		articoliAcceduti = new HashMap<>();
		
		articoliScrittura = new HashMap<>();
		
		articoli = new ArrayList<>();
		articoli.add(new Articolo("puzza","cacapupu"));
		articoli.add(new Articolo("cibo","il cibo è buono"));
		
	}
	
	public Map<String, HttpSession> getScritture() {
		return articoliScrittura;
	}
	
	public Map<HttpSession, String> getAcceduti() {
		return articoliAcceduti;
	}
	
	public List<Articolo> getArticoli() {
		return this.articoli;
	}
	
	public synchronized Articolo getArticolo(String titolo){
		return articoli.stream().filter(a -> a.getName().equals(titolo)).findFirst().orElse(null);
	}
	
	public synchronized boolean addScrittura(String titolo, HttpSession session) {
		if(this.articoliScrittura.get(titolo) != null) return false;
		else {
			this.articoliScrittura.put(titolo, session);
			return true;
		}
	}
	
	public synchronized void releaseScrittura(String titolo) {
		this.articoliScrittura.put(titolo, null);
	}
	
}
