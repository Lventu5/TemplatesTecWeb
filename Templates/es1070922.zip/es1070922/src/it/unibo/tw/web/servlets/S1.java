package it.unibo.tw.web.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Articolo;
import it.unibo.tw.web.beans.Data;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson g = new Gson();
		String name = request.getParameter("name");
		Data d = (Data) getServletContext().getAttribute("dati");
		Articolo res;
		
		if((res=d.getArticolo(name))==null) res = new Articolo(name,"");
		d.getAcceduti().put(request.getSession(),res.getName());
		response.getWriter().append(g.toJson(res));
	}

}
