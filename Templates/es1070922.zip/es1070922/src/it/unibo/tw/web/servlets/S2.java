package it.unibo.tw.web.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Articolo;
import it.unibo.tw.web.beans.Data;

public class S2 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String m = request.getParameter("m");
		Data d = (Data) getServletContext().getAttribute("dati");
		boolean res;
		String r;
		
		if(m.equals("release")) {
			d.releaseScrittura(name);
			response.getWriter().append("rel");
		}
		else {
			res=d.addScrittura(name,request.getSession());
			if(res) r = "true";
			else r = "false";
			response.getWriter().append(r);
		}
		
	}

}
