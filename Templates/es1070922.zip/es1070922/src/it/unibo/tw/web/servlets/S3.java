package it.unibo.tw.web.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Articolo;
import it.unibo.tw.web.beans.Data;

public class S3 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String t = request.getParameter("text");
		Data d = (Data) getServletContext().getAttribute("dati");
		
		if(d.getScritture().get(name) != null) {
			d.getArticolo(name).write(t);
			response.getWriter().append("true");
		}
		else response.getWriter().append("false");
	}

}
