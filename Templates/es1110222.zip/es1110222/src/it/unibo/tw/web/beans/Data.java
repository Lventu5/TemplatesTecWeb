package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {

	private static final long serialVersionUID = 1L;

	private HttpSession admin;
	private List<LocalDateTime> elabTimes;
	private Map<String, String> utenti;
	
	public Data() {
		super();
		
		elabTimes = new ArrayList<>();
		
		utenti = new HashMap<>();
		utenti.put("admin", "admin");
	}
	
	public HttpSession getAdmin() {
		return admin;
	}

	public void setAdmin(HttpSession admin) {
		this.admin = admin;
	}

	public List<LocalDateTime> getElabTimes() {
		return this.elabTimes;
	}
	
	public synchronized long elabsIn(int days){
		return elabTimes.stream().filter(ldt -> Duration.between(ldt, LocalDateTime.now()).toDays()<=days).count();
	}
	
	public Map<String, String> getUtenti() {
		return utenti;
	}
	
	public synchronized boolean isRegistered(String un) {
		return utenti.containsKey(un);
	}
	
	public synchronized boolean validLogin(String un, String pw) {
		return (this.isRegistered(un) && utenti.get(un)!=null && utenti.get(un).equals(pw));
	}
}
