package it.unibo.tw.web.beans;

public class Req {
	private String val;
	private char car;
	public String getVal(){ return val; }
	public char getCar(){ return car; }
	public Req(String s, char c) {val=s; car=c;}
}