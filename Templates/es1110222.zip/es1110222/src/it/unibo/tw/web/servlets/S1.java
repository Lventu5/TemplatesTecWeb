package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;
import it.unibo.tw.web.beans.Req;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		Gson g = new Gson();
		Req params = (Req)g.fromJson(request.getReader(), Req.class);
		
		String path = "D:\\loren\\eclipse-workspace\\es1110222\\src\\it\\unibo\\tw\\web\\servlets\\"+params.getVal();
		BufferedReader rd = new BufferedReader(new FileReader(path));
		Data d = (Data) getServletContext().getAttribute("dati");

		char c = params.getCar();
		StringBuilder sb = new StringBuilder();
		String line;
		
		while((line = rd.readLine()) != null) {
			sb.append(line.replace(""+c, ""));
			sb.append("\n");
		}
		if(d.getAdmin() != null && request.getSession().equals(d.getAdmin())) {
			int num = (int)d.getAdmin().getAttribute("elabs");
			num++;
			d.getAdmin().setAttribute("elabs",num);
		}
		
		rd.close();
		request.setAttribute("text", sb.toString());
		getServletContext().getRequestDispatcher("/J2.jsp").forward(request, response);
	}

}
