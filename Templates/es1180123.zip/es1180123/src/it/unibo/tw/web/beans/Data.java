package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<String> tabellone;
	private Map<String,HttpSession> results;
	private Map<String, String> utenti;
	private boolean gameOn;
	
	public Data() {
		super();
		tabellone = new ArrayList<>();
		
		results = new HashMap<>();
		
		utenti = new HashMap<>();
		utenti.put("admin", "admin");
		
		gameOn = false;
	}
	
	public List<String> getTabellone() {
		return this.tabellone;
	}
	
	public void setTabellone(List<String> tabellone) {
		this.tabellone = tabellone;
	}

	public Map<String, String> getUtenti() {
		return utenti;
	}
	
	public Map<String, HttpSession> getResults() {
		return results;
	}

	public boolean isGameOn() {
		return gameOn;
	}

	public void setGameOn(boolean gameOn) {
		this.gameOn = gameOn;
	}

	public synchronized boolean isRegistered(String un) {
		return utenti.containsKey(un);
	}
	
	public synchronized boolean validLogin(String un, String pw) {
		return (this.isRegistered(un) && utenti.get(un)!=null && utenti.get(un).equals(pw));
	}
}
