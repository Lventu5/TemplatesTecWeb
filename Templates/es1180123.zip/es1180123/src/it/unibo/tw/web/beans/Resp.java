package it.unibo.tw.web.beans;

public class Resp {
	private String val;
	private int res;
	public String getVal(){ return val; }
	public int getRes() { return res;}
	public Resp(String s, int n) {val=s; res = n;}
}