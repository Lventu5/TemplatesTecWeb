package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;
import it.unibo.tw.web.beans.Req;
import it.unibo.tw.web.beans.Resp;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		Gson g = new Gson();
		
		String name = request.getParameter("name");
		Data d = (Data) getServletContext().getAttribute("dati");
		Resp r = new Resp("Error",0);
		
		if(d.isGameOn() && !d.getTabellone().contains(name)) r = new Resp("Posti terminati",0);
		else if(!d.isGameOn() && d.getTabellone().contains(name)) r = new Resp("Sorteggio non ancora avvenuto", 0);
		else if(!d.isGameOn() && !d.getTabellone().contains(name)) {
			d.getTabellone().add(name);
			d.getResults().put(name, request.getSession());
			r = new Resp("Iscrizione avvenuta, attendi il sorteggio",0);
		}
		
		if(!d.isGameOn() && d.getTabellone().size()==8 && d.getTabellone().contains(name)) {
			d.setGameOn(true);
			List<String> temp = d.getTabellone();
			Collections.shuffle(temp);
			d.setTabellone(temp);
			int i = temp.indexOf(name);
			if(i%2==0) i++;
			else i--;
			
			r = new Resp(temp.get(i),1);
		}
		else if(d.isGameOn() && d.getTabellone().contains(name)) {
			int i = d.getTabellone().indexOf(name);
			if(i%2==0) i++;
			else i--;
			
			r = new Resp(d.getTabellone().get(i),1);
		}
		
		response.getWriter().append(g.toJson(r));
	}

}
