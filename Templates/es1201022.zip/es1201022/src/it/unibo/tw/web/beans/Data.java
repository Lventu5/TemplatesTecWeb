package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {
	private Map<String,Double> drinks;
	private Map<Integer,List<Drink>> tables;

	private static final long serialVersionUID = 1L;
	
	public Data() {
		super();
		drinks = new HashMap<>();
		tables = new HashMap<>();
		
		drinks.put("Gin Tonic", 7.00);
		drinks.put("Gin Lemon", 7.00);
		drinks.put("Vodka Tonic", 7.00);
		drinks.put("Vodka Lemon", 7.00);
		drinks.put("Mojito", 7.00);
		
	}
	
	public Map<String,Double> getDrinks(){
		return drinks;
	}
	
	public Map<Integer,List<Drink>> getTables(){
		return tables;
	}
	
	public synchronized double getBill(int tb) {
		return (this.tables.get(tb).stream().map(d -> d.getPrice()).reduce((a,b) -> a+b)).get();
	}
	
	public synchronized double getOwnBill(int tb, HttpSession s) {
		return (this.tables.get(tb).stream().filter(dr -> (dr.getSess().equals(s) && dr.getState().equals("consegnato"))).map(d -> d.getPrice()).reduce((a,b) -> a+b)).orElse((double) 0);
	}
	
}
