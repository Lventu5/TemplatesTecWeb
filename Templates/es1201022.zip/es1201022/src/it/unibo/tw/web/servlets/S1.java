package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;
import it.unibo.tw.web.beans.Drink;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("drink");
		Data d = (Data) getServletContext().getAttribute("dati");
  		int table = (int)request.getSession().getAttribute("Table");
		
		if(d.getDrinks().containsKey(name) && getServletContext().getAttribute("closed")==null){
			if(d.getTables().containsKey(table)) {
				d.getTables().get(table).add(new Drink(name,"ordinato",d.getDrinks().get(name),request.getSession()));
			}
			else {
				d.getTables().put(table, new ArrayList<Drink>());
				d.getTables().get(table).add(new Drink(name,"ordinato",d.getDrinks().get(name),request.getSession()));
			}
		}
		else {
			response.getWriter().append("err");
		}
		response.sendRedirect(request.getContextPath()+"/index.jsp");
		
	}

}
