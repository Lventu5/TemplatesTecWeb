package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;

public class S2 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		int tab = Integer.parseInt(request.getParameter("tab"));
		int mode = Integer.parseInt(request.getParameter("m"));
		Data d = (Data) getServletContext().getAttribute("dati");
		
		if(mode==1) {
			double res = d.getBill(tab);
			if(getServletContext().getAttribute("closed")==null) {
				writer.append("Conto totale del tavolo :" + res);
			}
			else if(res<100){
				res=100;
				writer.append("Conto totale del tavolo :" + res);
			}
		}
		else if(mode==2) {
			writer.append("Conto personale :" + d.getOwnBill(tab, request.getSession()));
		}
		
		
	}

}
