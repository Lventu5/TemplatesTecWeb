package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;

public class User implements Serializable {
	private String uName, pwd;
	private int money;
	

	private static final long serialVersionUID = 1L;
	
	public User(String name, String pwd) {
		super();
		this.uName=name;
		this.pwd=pwd;
		this.money=150;
	}
	
	public String getUname() {
		return this.uName;
	}
	
	public String getPwd() {
		return this.pwd;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}
	

}