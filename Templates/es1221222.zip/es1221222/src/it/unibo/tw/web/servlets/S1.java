package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;
import it.unibo.tw.web.beans.Req;
import it.unibo.tw.web.beans.Resp;
import it.unibo.tw.web.beans.User;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static String []actual = new String[30];

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		Data d = (Data) getServletContext().getAttribute("dati");
		
		LocalDateTime tr = LocalDateTime.now();
		int card = Integer.parseInt(request.getParameter("card"));
		int offer = Integer.parseInt(request.getParameter("off"));
		
		if(!d.getSelling().containsKey(card)) {
			response.getWriter().append("Carta non in vendita!");
		}
		else if(Duration.between(d.getSelling().get(card), tr).toSeconds()>60) {
			for(Entry<User,List<Integer>> e : d.getGioco().entrySet()) {
				if(e.getValue().contains(card)) {
					e.getValue().remove(card);
					e.getKey().setMoney(e.getKey().getMoney()+offer);
				}
				else if(e.getKey().getUname().equals(actual[(card)])) {
					e.getKey().setMoney(e.getKey().getMoney()-offer);
					e.getValue().add(card);
				}
			}
			d.getSelling().remove(card);
			response.getWriter().append("Vendita conclusa, carta ottenuta da "+actual[(card)]);
		}
		else {
			actual[(card)] = name;
			d.getSelling().put(card,tr);
			response.getWriter().append("Offerta inserita");
		}
		
		
	}

}
