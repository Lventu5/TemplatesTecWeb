package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Map<String,String> utenti; 
	private Map<User, List<Regalo>> gioco;
	private List<Regalo> regali;
	private boolean gameOn;
	private LocalDateTime start;
	private String leader;
	private Regalo selling;
	
	public Data() {
		super();
		
		utenti = new HashMap<>();
		
		regali = new ArrayList<>();
		regali.add(new Regalo("prova","prova",5));
		regali.add(new Regalo("prova1","prova1",15));
		regali.add(new Regalo("prova2","prova2",25));
		
		gioco = new HashMap<>();
		
		gameOn = false;
	}

	public Map<String, String> getUtenti() {
		return utenti;
	}

	public Map<User, List<Regalo>> getGioco() {
		return gioco;
	}

	public List<Regalo> getRegali() {
		return regali;
	}

	public boolean isGameOn() {
		return gameOn;
	}

	public void setGameOn(boolean gameOn) {
		this.gameOn = gameOn;
		this.start = LocalDateTime.now();
	}
	
	public LocalDateTime getStart() {
		return start;
	}
	
	public String getLeader() {
		return leader;
	}

	public void setLeader(String s) {
		this.leader = s;
	}
	
	public Regalo getSelling() {
		return selling;
	}
	
	public void setSelling(Regalo selling) {
		this.selling = selling;
	}

	public synchronized boolean isRegistered(String un) {
		return utenti.containsKey(un);
	}
	
	public synchronized boolean validLogin(String un, String pw) {
		return (this.isRegistered(un) && utenti.get(un)!=null && utenti.get(un).equals(pw));
	}
	
	public synchronized void addUser(User u) {
		if(!this.gioco.containsKey(u)) {
			this.gioco.put(u, new ArrayList<>());
		}
		if(this.gioco.size()>=2 && !this.isGameOn()) this.setGameOn(true);
	}
}
