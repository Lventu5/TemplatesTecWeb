package it.unibo.tw.web.beans;

public class Req {
	private String val;
	private int off;
	public String getVal(){ return val; }
	public int getOff() { return off;}
	public Req(String s, int n) {val=s; off = n;}
}