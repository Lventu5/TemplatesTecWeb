package it.unibo.tw.web.beans;

public class Resp {
	private String val;
	public String getVal(){ return val; }
	public Resp(String s) {val=s;}
}