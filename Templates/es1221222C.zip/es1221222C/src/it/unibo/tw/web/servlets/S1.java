package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unibo.tw.web.beans.Data;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Data d = (Data) getServletContext().getAttribute("dati");
		Random r = new Random();
		int ind = r.nextInt(0, d.getRegali().size());
		
		d.setLeader("");
		d.setSelling(d.getRegali().get(ind));
		d.getRegali().remove(ind);
		response.sendRedirect(request.getContextPath()+"/J1.jsp");
	}

}
