package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Catalogo implements Serializable {
	private List<Prodotto> catalogo;
	
	private static final long serialVersionUID = 1L;
	
	public Catalogo() {
		super();
		catalogo = new ArrayList<>();
		
		catalogo.add(new Prodotto("123","Computer",999.99,10));
		catalogo.add(new Prodotto("234","Matita",1.99,100));
		catalogo.add(new Prodotto("345","Caricabatterie",15.99,15));
		catalogo.add(new Prodotto("456","Mouse",25.99,12));
	}
	
	public List<Prodotto> getCatalogo() {
		return catalogo;
	}
	
	public Prodotto getProd(String id) {
		return catalogo.stream().filter(p -> p.getId().equals(id)).findFirst().get();
	}
}
