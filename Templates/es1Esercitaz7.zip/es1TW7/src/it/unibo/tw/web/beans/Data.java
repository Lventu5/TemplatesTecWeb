package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Data implements Serializable {
	private Map<User, Integer> groups;
	private Map<Integer, List<Prodotto>> cart;

	private static final long serialVersionUID = 1L;
	
	public Data() {
		super();
		groups = new HashMap<>();
		cart = new HashMap<>();
		
		groups.put(new User("peppe","brescia"), 1);
		groups.put(new User("pippo","nana"), 1);
		groups.put(new User("abcd","1234"), 2);
		groups.put(new User("io","2345"), 2);
		groups.put(new User("aaa","aaa"), 2);
		groups.put(new User("bbb","bbb"), 3);
		groups.put(new User("ccc","ccc"), 3);
		groups.put(new User("ddd","ddd"), 3);
		
		cart.put(1, new ArrayList<>());
		cart.put(2, new ArrayList<>());
		cart.put(3, new ArrayList<>());
	}
	
	public Map<User, Integer> getGroups(){
		return groups;
	}
	
	public Map<Integer, List<Prodotto>> getCarts(){
		return cart;
	}
	
	public List<Prodotto> getCart(int index){
		return cart.get(index);
	}
	
	public boolean isReg(String uName, String pwd) {
		for(User u : groups.keySet()) {
			if(u.getUname().equals(uName) && u.getPwd().equals(pwd)) return true;
		}
		return false;
	}
	
	public int getGroupId(String uName, String pwd) {
		for(Entry<User, Integer> e : groups.entrySet()) {
			if(e.getKey().getUname().equals(uName) && e.getKey().getPwd().equals(pwd))
				return e.getValue().intValue();
		}
		return -1;
	}
	
	public User getUser(String uName, String pwd) {
		for(User u : groups.keySet()) {
			if(u.getUname().equals(uName) && u.getPwd().equals(pwd)) return u;
		}
		return null;
	}
	
}
