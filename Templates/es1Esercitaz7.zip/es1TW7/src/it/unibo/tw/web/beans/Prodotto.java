package it.unibo.tw.web.beans;

import java.io.Serializable;

public class Prodotto implements Serializable {
	private String id, description;
	private double price;
	private int quant;
	

	private static final long serialVersionUID = 1L;
	
	public Prodotto(String id, String desc, double p, int n) {
		super();
		this.id = id;
		this.description = desc;
		this.price = p;
		this.quant = n;
	}
	
	public void setQuant(int diff) {
		this.quant = this.quant + diff;
	}
	
	public String getId() {
		return id;
	}
	
	public String getDesc() {
		return description;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getQuant() {
		return quant;
	}
}