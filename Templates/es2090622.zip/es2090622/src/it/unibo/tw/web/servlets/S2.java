package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class S2 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String text = request.getParameter("val");
		PrintWriter wr = response.getWriter();
		String []arr = new String[10];
		String temp="", vowels="aeiou";
		List<String> chr = Arrays.asList(text.split(""));
		
		for(int i=0;i<10;i++) {
			temp="";
			do {
				Collections.shuffle(chr);
			} while(vowels.indexOf(chr.get(0).charAt(0)) != -1);
			
			for( String s : chr) {
				temp+=s;
			}
			
			arr[i]=temp;
		}
		
		for(String s: arr) {
			wr.append(s+"\n");
		}
	}

}
