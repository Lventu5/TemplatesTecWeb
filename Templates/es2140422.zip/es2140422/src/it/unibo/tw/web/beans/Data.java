package it.unibo.tw.web.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

public class Data implements Serializable {

	private static final long serialVersionUID = 1L;

	private Map<HttpSession,Boolean> sessions;
	
	public Data() {
		super();
		sessions = new HashMap<>();
	}
	
	public Map<HttpSession, Boolean> getSessions() {
		return sessions;
	}
}