package it.unibo.tw.web.beans;

public class Request {
	public String[] nums;
	public Request(){
	}
	public String[] getNums() {
		return this.nums;
	}
}
