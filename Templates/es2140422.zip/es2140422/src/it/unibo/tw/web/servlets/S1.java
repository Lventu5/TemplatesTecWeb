package it.unibo.tw.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import it.unibo.tw.web.beans.Data;
import it.unibo.tw.web.beans.Request;

public class S1 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = response.getWriter();
		Gson g = new Gson();
		Data d = null;
		Request req = (Request)g.fromJson(request.getReader(), Request.class);
		HttpSession session = request.getSession();
		
		
		if(getServletContext().getAttribute("dati") == null) {
			d = new Data();
			d.getSessions().put(session,false);
			getServletContext().setAttribute("dati", d);
		}
		else {
			d = (Data)getServletContext().getAttribute("dati");
			if(d.getSessions().containsKey(session) && d.getSessions().get(session).booleanValue()) {
				writer.append("richiesta terminata dall'amministratore");
				d.getSessions().put(session,false);
				return;
			}
			else if(!d.getSessions().containsKey(session)) d.getSessions().put(session,false);
		}
		
		boolean res = true;
		
		List<Integer> vals = Arrays.stream(req.getNums()).map(s -> Integer.parseInt(s)).toList();
		for(int i=0;i<vals.size() && res;i+=2) {
			if(vals.get(i).intValue()!=vals.get(i+1).intValue()) res = false;
		}
		
		if(res)
			writer.append("true");
		else 
			writer.append("false");
	}
}