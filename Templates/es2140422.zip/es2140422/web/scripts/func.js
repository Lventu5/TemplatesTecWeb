function myFunction(el)
{
	if(isNaN(parseInt(el.value)) && el.value!=='')
		{
			alert("il valore inserito non e' un numero");
			return;
		}
	check();
}

function check(){
	var compl = true;
	var n1 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], n2=[0,0,0,0,0,0,0,0,0,0,0,0];
	var diag = [0,7,14,21,28,35];
	var gr1 = [1,6,2,12,3,18,4,24,5,30,8,13,9,19,10,25,11,31], gr2 = [15,20,16,26,17,32,22,27,23,33,29,34];
	var r1='', r2='';
	for(var i=0; i<36 && compl; i++){
		var id = "a"+i;
		if(document.getElementById(id).value === '') compl=false;
		else {
			if(gr1.includes(i)) n1[gr1.indexOf(i)] = document.getElementById(id).value;
			else if(!diag.includes(i)) n1[gr1.indexOf(i)] = document.getElementById(id).value;
		}
	}
	
	if(compl){
		fetch('s1', {
			method: 'POST',
			headers: {
				'Accept': 'text/plain',
				'Content-Type': 'application/json',
				'charset': 'UTF-8'
			},
			body: JSON.stringify({
				nums: n1
			}),
			cache: 'no-store'
		})
		.then(response => response.text())
		.then((data) => {
			r1=data;
			if(r1!=='' && r1!=='true' && r1!=='false') alert(r1);
			else if(r2==='true' && r1==='true') document.getElementById('tot').innerHTML = "L'elemento &egrave; una matrice simmetrica"
			else if(r1==="false" || (r2!=='' && r2==="false")) document.getElementById('tot').innerHTML = "L'elemento non &egrave; una matrice simmetrica"
		})
		
		fetch('s2', {
			method: 'POST',
			headers: {
				'Accept': 'text/plain',
				'Content-Type': 'application/json',
				'charset': 'UTF-8'
			},
			body: JSON.stringify({
				nums: n2
			}),
			cache: 'no-store'
		})
		.then(response => response.text())
		.then((data) => {
			r2=data;
			if(r2!=='' && r2!=='true' && r2!=='false') alert(r2);
			else if(r2==='true' && r1==='true') document.getElementById('tot').innerHTML = "L'elemento &egrave; una matrice simmetrica"
			else if(r2==="false" || (r1!=='' && r1==="false")) document.getElementById('tot').innerHTML = "L'elemento non &egrave; una matrice simmetrica"
		})
	}
}
