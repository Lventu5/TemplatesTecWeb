package it.unibo.tw.web.beans;

import java.io.Serializable;

public class News implements Serializable {
	private String name;
	private int cat;
	private String val;

	private static final long serialVersionUID = 1L;

	public News(String name, int cat, String val) {
		super();
		this.name = name;
		this.cat = cat;
		this.val = val;
	}

	public String getName() {
		return name;
	}

	public int getCat() {
		return cat;
	}

	public String getVal() {
		return val;
	}

}