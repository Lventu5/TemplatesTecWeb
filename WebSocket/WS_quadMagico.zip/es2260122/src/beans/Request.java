package beans;

public class Request {
	public String[] nums;
	public Request(){
	}
	public String[] getNums() {
		return this.nums;
	}
}
