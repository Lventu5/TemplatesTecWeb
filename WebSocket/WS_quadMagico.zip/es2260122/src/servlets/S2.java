package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import beans.Request;
import beans.Result;

public class S2 extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		PrintWriter writer = response.getWriter();
		Gson g = new Gson();
		Request req = (Request)g.fromJson(request.getReader(), Request.class);
		List<Integer> vals = Arrays.stream(req.getNums()).map(s -> Integer.parseInt(s)).toList();
		int somma = vals.get(0).intValue()+vals.get(3).intValue()+vals.get(6).intValue();
		Result res = null;
		
		if(somma == vals.get(1).intValue()+vals.get(4).intValue()+vals.get(7).intValue() && somma == vals.get(2).intValue()+vals.get(5).intValue()+vals.get(8).intValue()
				&& somma == vals.get(0).intValue()+vals.get(4).intValue()+vals.get(8).intValue() && somma == vals.get(2).intValue()+vals.get(4).intValue()+vals.get(6).intValue()) {
			res = new Result("true", somma);
		}
		else res = new Result("false", -1);
		
		writer.append(g.toJson(res));
	}
}