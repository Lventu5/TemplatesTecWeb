package beans;

public class OperationReq2 {
	
	String id;
	String value;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public OperationReq2() {
		super();
	}
	@Override
	public String toString() {
		return "OperationReq [id=" + id + ", value=" + value + "]";
	}

}
