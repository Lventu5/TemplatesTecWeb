package beans;

public class Result {
	public String res;
	public int somma;
	public Result(String res, int s){
		this.res = res; this.somma = s;
	}
	public String getRes() {
		return this.res;
	}
	public int getSomma() {
		return this.somma;
	}
}
