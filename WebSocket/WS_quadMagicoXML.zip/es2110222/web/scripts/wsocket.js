const socket = new WebSocket("ws://localhost:8080/es2110222/actions");

function send( data) {
    var json = JSON.stringify(data);

    socket.send(json);
}


socket.onmessage =  function (event){
	
	var message = JSON.parse(event.data);

 	var log = document.getElementById(message.id);
	log.value = "";
    console.log(event.data);
   
    log.value = message.value;
	
	check();
}

function myFunction(el)
{
	if(isNaN(parseInt(el.value)) && el.value!=='')
		{
			alert("il valore inserito non e' un numero");
			return;
		}
	var operationReq = {};
	operationReq.id = el.id;
	operationReq.value = el.value;
	
	send(operationReq);
	
	check();
	
}

function check(){
	var compl = true;
	var n = [];
	var r1='', r2='', r3='';
	const parser = new DOMParser();
	for(var i=0; i<25 && compl; i++){
		var id = "a"+i;
		if(document.getElementById(id).value === '') compl=false;
		else n.push(document.getElementById(id).value);
	}
	
	if(compl){
		fetch('s1', {
			method: 'POST',
			headers: {
				'Accept': 'text/xml',
				'Content-Type': 'application/json',
				'charset': 'UTF-8'
			},
			body: JSON.stringify({
				nums: n
			}),
			cache: 'no-store'
		})
		.then(response => response.text())
		.then((data) => {
			var xml = parser.parseFromString(data, "text/xml");
			var rootElement = xml.getElementsByTagName("root")[0];
			var res = rootElement.getElementsByTagName("res")[0].innerHTML;
			var sum = rootElement.getElementsByTagName("sum")[0].innerHTML;

			document.getElementById('res1').innerHTML = "Somma righe uguale: "+res+ (res==="true" ? ", somma: "+sum : '') + "<br/>"
			r1=res;
			if(r2==='true' && r1==='true' && r3==='true') document.getElementById('tot').innerHTML = "L'elemento &egrave; un quadrato magico"
			else if(r1==="false" || (r2!=='' && r2==="false") || (r3!=='' && r3==="false")) document.getElementById('tot').innerHTML = "L'elemento non &egrave; un quadrato magico"
		})

		fetch('J2.jsp', {
			method: 'POST',
			headers: {
				'Accept': 'text/xml',
				'Content-Type': 'application/json',
				'charset': 'UTF-8'
			},
			body: JSON.stringify({
				nums: n
			}),
			cache: 'no-store'
		})
		.then(response => response.text())
		.then((data) => {
			var xml = parser.parseFromString(data, "text/xml");
			var rootElement = xml.getElementsByTagName("root")[0];
			var res = rootElement.getElementsByTagName("res")[0].innerHTML;
			var sum = rootElement.getElementsByTagName("sum")[0].innerHTML;

			document.getElementById('res2').innerHTML = "Somma colonne uguale: "+res+ (res==="true" ? ", somma: "+sum : '') + "<br/>"
			r2=res;
			if(r2==='true' && r1==='true' && r3==='true') document.getElementById('tot').innerHTML = "L'elemento &egrave; un quadrato magico"
			else if(r2==="false" || (r1!=='' && r1==="false") || (r3!=='' && r3==="false")) document.getElementById('tot').innerHTML = "L'elemento non &egrave; un quadrato magico"
		})	
		
		fetch('s3', {
			method: 'POST',
			headers: {
				'Accept': 'text/xml',
				'Content-Type': 'application/json',
				'charset': 'UTF-8'
			},
			body: JSON.stringify({
				nums: n
			}),
			cache: 'no-store'
		})
		.then(response => response.text())
		.then((data) => {
			var xml = parser.parseFromString(data, "text/xml");
			var rootElement = xml.getElementsByTagName("root")[0];
			var res = rootElement.getElementsByTagName("res")[0].innerHTML;
			var sum = rootElement.getElementsByTagName("sum")[0].innerHTML;

			document.getElementById('res3').innerHTML = "Somma diagonali uguale: "+res+ (res==="true" ? ", somma: "+sum : '') + "<br/>"
			r3=res;
			if(r2==='true' && r1==='true' && r3==='true') document.getElementById('tot').innerHTML = "L'elemento &egrave; un quadrato magico"
			else if(r3==="false" || (r1!=='' && r1==="false") || (r2!=='' && r2==="false")) document.getElementById('tot').innerHTML = "L'elemento non &egrave; un quadrato magico"
		})
	}
}
