const socket = new WebSocket("ws://localhost:8080/es3180123/actions");

function send( data) {
    var json = JSON.stringify(data);

    socket.send(json);
}


socket.onmessage =  function (event){
	
	var message = event.data;
	
 	var log = document.getElementById('res');
    console.log(event.data);
   
    log.innerHTML += message + '<br/>';
}

function myFunction(el, u, ev)
{
	ev.preventDefault();
	var operationReq = {};
	operationReq.user = u;
	
	if(u==="admin" && el.id==="ins"){
		operationReq.type = 1;
		operationReq.value = "<"+el["p1"].value+","+el["p2"].value+","+el["gen"].value+","+el["pun"].value+">";
	} 
	else if(u==="admin" && el.id==="results"){
		operationReq.type = 2;
		operationReq.value = "iscritti";
	}
	else if(u==="user"){
		operationReq.type = 1;
		operationReq.value = document.getElementById("gen").value;
	}
	
	send(operationReq);		
}
