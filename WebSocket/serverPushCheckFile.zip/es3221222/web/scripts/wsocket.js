const socket = new WebSocket("ws://localhost:8080/es3221222/actions");

function send( data) {
    socket.send(data);
}


socket.onmessage =  function (event){
	
	var message = event.data;
	
 	var log = document.getElementById('res');
 	if(log.className==="adminRes"){
		 var arr = message.split("<br>");
		 var html='<ul>';
		 for(var i=0;i<arr.length;i++){
			 html+='<li>'+arr[i]+': '+'<button id="term'+i+'" name="results" onclick="myFunction(\''+arr[i]+'\',event)">Revoca</button></li>';
		 }
		 html+="</ul>"
		 log.innerHTML = html;
	}
	else{
		log.innerHTML = message;
	}
    console.log(event.data);
}

function myFunction(u, ev)
{
	ev.preventDefault();
	
	send(u);		
}
